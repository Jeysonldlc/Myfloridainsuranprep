
fetch('questions.json')
    .then(response => response.json())
    .then(data => {
        document.getElementById('exam-container').innerText = 'Loaded ' + data.questions.length + ' questions.';
    });
