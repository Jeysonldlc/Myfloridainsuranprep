
# Florida 2-20 Practice Exam App

This is a lightweight, browser-based practice exam system designed to help candidates prepare for the Florida 2-20 General Lines Agent licensing exam.

## Features
- 160 randomized questions with explanations
- Real-time feedback and scoring
- Mobile-installable (PWA-ready)
- Works offline or hosted

## Deployment
This app can be hosted on Netlify, GitHub Pages, or run locally via a browser.

## License
MIT License - Open educational tool.
